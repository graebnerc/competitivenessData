GENERAL FORMAT OF THE FILES                        BASE YEAR FOR CALCULATIONS : 2010=100

First set of files: present definitions EA17, EU27, IC37 and broad group (42)

FIRST CHAR.    A        Annual     from 1994 onwards
               Q        Quarterly  from 1994 Q1 onwards
               M        Monthly    from Jan 1994 onwards


SECOND AND     19       each member of gr42 compared to the Euro area (EA19)    
THIRD CHAR.    27       each member of gr42 and 1 aggregate compared to the European Union (EU27)
               37       each member of gr42 and 2 aggregates compared to rest of IC37
               42       each member of the broad group (42) and 2 aggregates compared to the rest of the group
                        (for gr42: only HICP/CPI deflated REER available) 

    
LAST           NEER     Nominal Effective Exchange Rate
CHARACTERS
               REER     Real Effective Exchange Rate Nominal unit labour cost, total economy
                        by deflator                  Price deflator GDP, market prices
                                                     Price deflator exports of goods/services
                                                     Price deflator HICP / CPI

               WGHTS    Weight matrices


-----------------------------------------------------------
files:  a19neer.xls  a27neer.xls  a37neer.xls  a42neer.xls
        q19neer.xls  q27neer.xls  q37neer.xls  q42neer.xls
        m19neer.xls  m27neer.xls  m37neer.xls  m42neer.xls
        a19reer.xls  a27reer.xls  a37reer.xls  a42reer.xls
        q19reer.xls  q27reer.xls  q37reer.xls  q42reer.xls
        m19reer.xls  m27reer.xls  m37reer.xls  m42reer.xls
        a19wghts.xls a27wghts.xls a37wghts.xls a42wghts.xls
-----------------------------------------------------------

NOTE:
----
exchange rates: last value 31 August 2020
HICP deflator: last value August 2020 (missing data: IMF-IFS CPI; Ecfin and IMF-WEO forecasts)
other deflators: European Commission - DG Ecfin's Spring 2020 Forecast

-----------------------------------
countries covered and country codes
-----------------------------------
Belgium   c124
Bulgaria   c918
Czech_Rep   c935
Denmark   c128
Germany   c134
Estonia   c939
Ireland   c178
Greece   c174
Spain   c184
France   c132
Croatia   c960
Italy   c136
Cyprus   c423
Latvia   c941
Lithuania   c946
Luxembourg   c137
Hungary   c944
Malta   c181
Netherlands   c138
Austria   c122
Poland   c964
Portugal   c182
Romania   c968
Slovenia   c961
Slovakia   c936
Finland   c172
Sweden   c144
United_Kingdom   c112
Norway   c142
Switzerland   c146
Turkey   c186
Russia   c922
USA   c111
Canada   c156
Mexico   c273
Brazil   c223
Australia   c193
New_Zealand   c196
Japan   c158
China   c924
Hong_Kong   c532
Korea   c542
-----
Euro_Area   c19
European_Union   c27
IC37   c37
gr42   c42